package com.example.githubapidemo.web;

import com.example.githubapidemo.dto.GitUser;
import com.example.githubapidemo.repo.GitRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

@RestController
@RequestMapping("/github")
public class GithubUserAPI {
    @Autowired
    GitRepo repo;

    @GetMapping("/getUser/{username}")
    public GitUser getUserDetailsFromGithub(@PathVariable String username){
        RestTemplate restTemplate = new RestTemplate();
        GitUser response = restTemplate.getForObject("https://api.github.com/users/" + username, GitUser.class);
        return response;
//        GitUser resp = restTemplate.getForObject("https://api.github.com/users/" + username, GitUser.class);
//        return resp;
//        return "Successfully got the request for" + username;
    }
    @GetMapping("/getUser/{id}")
    public GitUser getUserById(@PathVariable Integer id){
//        RestTemplate restTemplate = new RestTemplate();
        Optional<GitUser> gitUser = repo.findById(id);
        if(gitUser.isPresent()){
            return gitUser.get();
        }
        else{
            return new GitUser();
        }

    }
}
